public interface ICalculator {
    long calculateSalary(double coefficientSalary, int basicSalary, int responsibilitySalary, int overTime);
}
